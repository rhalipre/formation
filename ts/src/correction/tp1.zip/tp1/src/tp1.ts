export class HelloWorld {
    public sayHello(name: string = 'World') {
        return `Hello ${name}!`;
    }
}
