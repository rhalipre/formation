function sayHello(nom: string) {
    return 'Bonjour, ' + nom;
}

const user = 'Zenika';

console.log(sayHello(user));
