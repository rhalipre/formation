export class Album {
  constructor(public title: string) {
  }

  public toString(): string {
    return this.title;
  }
}
