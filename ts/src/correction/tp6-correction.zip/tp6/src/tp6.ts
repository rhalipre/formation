import * as _ from 'lodash';
import display from './Display';
import { JazzMusician } from './JazzMusician';
import { Musician } from './Musician';
import { RockStar } from './RockStar';
import { log } from './utils';
import { Album } from './Album';

const miles = new JazzMusician('Miles', 'Davis', 89);
miles.addAlbum(new Album('Kind Of Blue'));
miles.addAlbum(new Album('Tutu'));

const musicians: Musician[] = [
  miles,
  new RockStar('Mick', 'Jagger', 72),
];

log('Bienvenue dans ma première applications TypeScript');
display(musicians);
display(miles.albums);

_.each(musicians, musician => {
  if (musician instanceof JazzMusician) {
    musician.swing();
  } else if (musician instanceof RockStar) {
    musician.shout();
  }
});
