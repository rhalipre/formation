import { Music, Musician } from './Musician';
import { logged, StyleMusic } from './utils';


@StyleMusic({style : Music.JAZZ})
export class JazzMusician extends Musician {
  constructor(public firstName: string, public lastName: string, public age: number) {
    super(firstName, lastName, age);
  }

  @logged
  swing(): string {
    return 'I\'m swinging!';
  }
}

