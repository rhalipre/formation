import { Music, Musician } from './Musician';

export function log<T>(value: T): void {
  console.log(value);
}

export function logged(target: any, propertyKey: string, descriptor: PropertyDescriptor): PropertyDescriptor {
  const originalMethod = descriptor.value;

  if (originalMethod !== undefined) {
    descriptor.value = (...args: any[]) => {
      const result = originalMethod.apply(target, args);
      log(result);
      return result;
    };
  }

  return descriptor;
}

export function JazzMan<T extends new(...args: any[]) => Musician>(oldConstructor: T): T {
  return class extends oldConstructor {
    constructor(...args: any[]) {
      super(...args);
      this.style = Music.JAZZ;
    }
  };
}

export function Rocker<T extends new(...args: any[]) => Musician>(oldConstructor: T): T {
  return class extends oldConstructor {
    constructor(...args: any[]) {
      super(...args);
      this.style = Music.ROCK;
    }
  };
}

export function StyleMusic(option: { style: Music }) {
  return <T extends new(...args: any[]) => Musician>(oldConstructor: T): T => {
    return class extends oldConstructor {
      constructor(...args: any[]) {
        super(...args);
        this.style = option.style;
      }
    };
  };
}
