import { Album } from './Album';

export enum Music { JAZZ, ROCK }

export interface IMusician {
  addAlbum: (album: Album) => void;
}

export class Musician implements IMusician {
  private _style: Music | undefined;
  private _albums: Album[] = [];

  constructor(public firstName: string, public lastName: string, public age: number) {
  }

  get style(): Music | undefined {
    return this._style;
  }

  set style(value: Music | undefined) {
    this._style = value;
  }

  get albums(): Album[] {
    return this._albums;
  }

  set albums(value: Album[]) {
    this._albums = value;
  }

  public toString(): string {
    if (this.style === undefined) {
      return `${this.firstName} ${this.lastName} plays`;
    } else {
      return `${this.firstName} ${this.lastName} plays ${Music[this.style]}`;
    }
  }

  addAlbum(album: Album): void {
    this._albums.push(album);
  }
}
