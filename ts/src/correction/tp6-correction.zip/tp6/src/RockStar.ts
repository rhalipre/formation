import { Music, Musician } from './Musician';
import { logged, StyleMusic } from './utils';

@StyleMusic({style : Music.ROCK})
export class RockStar extends Musician {
  constructor(public firstName: string, public lastName: string, public age: number) {
    super(firstName, lastName, age);
  }

  @logged
  shout(): string {
    return 'I\'m shouting!';
  }
}
