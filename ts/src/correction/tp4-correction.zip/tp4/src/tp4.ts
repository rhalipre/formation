import { log } from './utils';
import { Musician } from './Musician';
import { JazzMusician } from './JazzMusician';
import { RockStar } from './RockStar';
import Display from './Display';
import { Album } from './Album';

const miles = new JazzMusician('Miles', 'Davis', 89);
miles.addAlbum(new Album('Kind Of Blue'));
miles.addAlbum(new Album('Tutu'));

const musicians: Musician[] = [
  miles,
  new RockStar('Mick', 'Jagger', 72),
];

log('Bienvenue dans ma première application TypeScript');
Display(musicians);
Display(miles.albums);

for (const musician of musicians) {
  if (musician instanceof JazzMusician) {
    musician.swing();
  } else if (musician instanceof RockStar) {
    musician.shout();
  }
}
