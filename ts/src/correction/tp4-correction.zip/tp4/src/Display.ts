import { log } from './utils';

export default function <T extends Record<string, any>>(objects: T[]): void {
  objects.forEach(element => {
    log(element.toString());
  });
}
