import { Music } from './Musician';
import { RockStar } from './RockStar';


describe('RockStar', () => {
  it('RockStar properties testing', () => {
    const musician = new RockStar('Mick', 'Jagger', 72);
    expect(musician.style).toBe(Music.ROCK);
  });

  it('RockStar toString method testing', () => {
    const musician = new RockStar('Mick', 'Jagger', 72);
    expect(musician.toString()).toBe('Mick Jagger plays ROCK');
  });

});
