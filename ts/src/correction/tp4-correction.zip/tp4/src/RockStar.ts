import { Music, Musician } from './Musician';
import { log } from './utils';

export class RockStar extends Musician {
  constructor(public firstName: string, public lastName: string, public age: number) {
    super(firstName, lastName, age);
    this.style = Music.ROCK;
  }

  shout(): void {
    log('I\'m shouting!');
  }
}
