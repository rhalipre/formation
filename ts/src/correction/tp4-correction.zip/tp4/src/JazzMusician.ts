import { Music, Musician } from './Musician';
import { log } from './utils';

export class JazzMusician extends Musician {
  constructor(public firstName: string, public lastName: string, public age: number) {
    super(firstName, lastName, age);
    this.style = Music.JAZZ;
  }

  swing(): void {
    log('I\'m swinging!');
  }
}
