export function log<T>(value: T): void {
  console.log(value);
}
