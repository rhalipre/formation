import { Music } from './Musician';
import { JazzMusician } from './JazzMusician';


describe('Jazz Musician', () => {
  it('JazzMusician properties testing', () => {
    const musician = new JazzMusician('Miles', 'Davis', 89);
    expect(musician.style).toBe(Music.JAZZ);
  });

  it('JazzMusician toString method testing', () => {
    const musician = new JazzMusician('Miles', 'Davis', 89);
    expect(musician.toString()).toBe('Miles Davis plays JAZZ');
  });
});
